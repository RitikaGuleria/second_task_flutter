// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'categoriesnames.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CategoriesNames _$$_CategoriesNamesFromJson(Map<String, dynamic> json) =>
    _$_CategoriesNames(
      idCategory: json['idCategory'] as String,
      strCategory: json['strCategory'] as String,
      strCategoryThumb: json['strCategoryThumb'] as String,
    );

Map<String, dynamic> _$$_CategoriesNamesToJson(_$_CategoriesNames instance) =>
    <String, dynamic>{
      'idCategory': instance.idCategory,
      'strCategory': instance.strCategory,
      'strCategoryThumb': instance.strCategoryThumb,
    };
