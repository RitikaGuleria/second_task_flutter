// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'combinedProvider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$combinedProviderHash() => r'b3c43a18348b683f9cbb9d1a08713b819ec8b34c';

/// See also [combinedProvider].
@ProviderFor(combinedProvider)
final combinedProviderProvider = AutoDisposeNotifierProvider<combinedProvider,
    List<CategoriesNames>>.internal(
  combinedProvider.new,
  name: r'combinedProviderProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$combinedProviderHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$combinedProvider = AutoDisposeNotifier<List<CategoriesNames>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
