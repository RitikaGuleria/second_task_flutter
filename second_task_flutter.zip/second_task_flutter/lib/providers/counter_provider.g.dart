// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'counter_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$counter_ProviderHash() => r'9e88809038966c26d95f5f6e99f7d02c94bd1a11';

/// See also [Counter_Provider].
@ProviderFor(Counter_Provider)
final counter_ProviderProvider =
    AutoDisposeNotifierProvider<Counter_Provider, int>.internal(
  Counter_Provider.new,
  name: r'counter_ProviderProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$counter_ProviderHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Counter_Provider = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
