// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'remove_tile_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$removeTileProviderHash() =>
    r'cf42d7809b6f74e223157c0aef572df54e508bb5';

/// See also [RemoveTileProvider].
@ProviderFor(RemoveTileProvider)
final removeTileProviderProvider = AutoDisposeNotifierProvider<
    RemoveTileProvider, List<CategoriesNames>>.internal(
  RemoveTileProvider.new,
  name: r'removeTileProviderProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$removeTileProviderHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RemoveTileProvider = AutoDisposeNotifier<List<CategoriesNames>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
